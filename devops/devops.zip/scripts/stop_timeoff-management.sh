#!/bin/bash
set -x
killall -s KILL node
