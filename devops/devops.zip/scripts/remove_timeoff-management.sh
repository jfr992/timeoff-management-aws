#!/bin/bash
set -ex
rm -rf /var/timeoff-management

